USERS OF THE STANDALONE COMPILER PLEASE NOTE

This applies if you are not using this compiler in conjunction with Wind River Workbench.  After installation, you must set up your environment to use the compiler. This can be done either manually or using the wrenv program.


SETTING UP THE ENVIRONMENT USING wrenv (Windows users)

The following fragment illustrates the use of wrenv to set up the environment on Windows hosts. The installation directory (installDir) is assumed to be C:\WindRiver:

C:\>cd \WindRiver
C:\WindRiver>wrenv -p diab-5.9.7.1 -f bat -o print_env > env.bat

C:\WindRiver>type env.bat
set Path=c:\WindRiver\compilers\diab-5.9.7.1\WIN32\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem
set WIND_PREFERRED_PACKAGES=diab-5.9.7.1
set WIND_HOME=c:\WindRiver
set WIND_DIAB_PATH=c:\WindRiver\compilers\diab-5.9.7.1
set WRSD_LICENSE_FILE=c:\WindRiver\license
set LM_A_APP_DISABLE_CACHE_READ=set
set WIND_TOOLCHAINS=diab
C:\WindRiver>env.bat

This step will need to be performed once after installation. Subsequently, the environment can be set up by executing env.bat. Please note that Path is set using the prevailing Path at the time wrenv is executed.

It can also be done in one step using:

C:\WindRiver>wrenv -p diab-5.9.7.1

A "Development Shell" is available to Windows users for interactive use. It is available under the program group that is created when the compiler is installed. The default program group is "Wind River > Wind River Compiler 5.9.7.1 The shell is started with all the required environment variables set up.


SETTING UP THE ENVIRONMENT USING wrenv (Linux users)

The following fragment illustrates the use of wrenv to set up the environment on Linux hosts. The installation directory (installDir) is assumed to be /home/<user>/WindRiver:

$ cd ~/WindRiver
$ wrenv.sh -p diab-5.9.7.1 -f sh -o print_env > env.sh

$ cat env.sh
WIND_DIAB_PATH="/home/user/WindRiver/compilers/diab-5.9.7.1"; export WIND_DIAB_PATH;
WIND_PREFERRED_PACKAGES="diab-5.9.7.1"; export WIND_PREFERRED_PACKAGES;
WRSD_LICENSE_FILE="/home/user/WindRiver/license"; export WRSD_LICENSE_FILE;
PATH="/home/user/WindRiver/compilers/diab-5.9.7.1/LINUX386/bin:.:/bin:/usr/bin:/usr/sbin:/usr/local/bin"; export PATH;
unset DIABLIB;
LM_A_APP_DISABLE_CACHE_READ="set"; export LM_A_APP_DISABLE_CACHE_READ;
WIND_HOME="/home/user/WindRiver"; export WIND_HOME;

$ . env.sh

For csh users, the following command lines

% cd /home/user/WindRiver
% wrenv.sh -p diab-5.9.7.1 -f csh -o print_env > env.csh

will produce csh style settings in env.csh.

$ source env.csh

This step will need to be performed once after installation. Subsequently, the environment can be set up by sourcing env.sh or env.csh. Please note that PATH is set using the prevailing PATH at the time wrenv is executed.

The environment can also be set up each time using this command:

$ wrenv.sh -p diab-5.9.7.1


SETTING UP THE ENVIRONMENT MANUALLY

 - define an environment variable called WRSD_LICENSE_FILE that points to the directory containing your license file.  In most cases, this directory will be installDir/license.

 - add the installation directory to your PATH variable:

   On Linux add installDir/compilers/diab-5.9.7.1/LINUX386/bin to PATH

   On Windows add installDir\compilers\diab-5.9.7.1\WIN32\bin to PATH

SETTING A DEFAULT TARGET (optional)

If you want to configure a default target and execution environment, run dctrl -t from the command prompt.  For more information about dctrl, see your Getting Started manual.

This final step is optional.  A target and execution environment can also be specified with the -t command-line option when the compiler is invoked. For information about -t, see the Wind River Compiler User's Guide for your target architecture.


Installation and Licensing

Please refer to the Developer Install Guide included in your shipment for details on how to install and activate this software. Further information can also be found online at http://www.windriver.com/licensing


Host Requirements

For important information regarding this product's host and operating system requirements, see the release notes supplied with this product. These release notes are also available on the product's support Web pages.


Product Documentation
 
For the comprehensive documentation set for your product, including release notes and getting started guide, go to:
https://knowledge.windriver.com/?cid=diab


Support

Up-to-date information on known problems, patches, and reference documentation can be obtained online.  Log on to Wind River's Online Support page at the URL below and navigate to the support pages for your product.

http://www.windriver.com/support

If you do not know your Wind River Support login, contact support@windriver.com.


v01.20190731